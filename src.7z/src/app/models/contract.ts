export interface Contract {
    id:number;
    contractName:string;
    dateEntry: string;
    contractValue: number;
    currency: number;
}

